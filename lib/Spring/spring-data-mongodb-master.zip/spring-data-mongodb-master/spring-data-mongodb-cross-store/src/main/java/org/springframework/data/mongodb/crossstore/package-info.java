/**
 * Infrastructure for Spring Data's MongoDB cross store support.
 */
package org.springframework.data.mongodb.crossstore;

