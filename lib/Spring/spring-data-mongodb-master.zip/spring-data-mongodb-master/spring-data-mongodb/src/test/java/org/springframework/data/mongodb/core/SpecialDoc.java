package org.springframework.data.mongodb.core;

public class SpecialDoc extends BaseDoc {
	String specialValue;
}
