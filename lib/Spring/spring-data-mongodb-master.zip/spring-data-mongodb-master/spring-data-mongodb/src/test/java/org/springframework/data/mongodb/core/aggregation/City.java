package org.springframework.data.mongodb.core.aggregation;

class City {

	String name;
	int population;

	public String toString() {
		return "City [name=" + name + ", population=" + population + "]";
	}
}
