package org.springframework.data.mongodb.core;

public class VerySpecialDoc extends SpecialDoc {
	int verySpecialValue;
}
