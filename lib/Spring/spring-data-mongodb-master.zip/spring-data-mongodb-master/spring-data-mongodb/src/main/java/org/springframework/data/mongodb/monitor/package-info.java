/**
 * MongoDB specific JMX monitoring support.
 */
package org.springframework.data.mongodb.monitor;

