/**
 * Spring Data MongoDB specific converter infrastructure.
 */
package org.springframework.data.mongodb.core.convert;

