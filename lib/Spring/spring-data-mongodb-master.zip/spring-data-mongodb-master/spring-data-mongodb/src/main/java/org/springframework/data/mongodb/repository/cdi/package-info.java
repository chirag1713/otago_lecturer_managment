/**
 * CDI support for MongoDB specific repository implementation.
 */
package org.springframework.data.mongodb.repository.cdi;

