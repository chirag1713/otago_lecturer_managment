/**
 * Support infrastructure for query derivation of MongoDB specific repositories.
 */
package org.springframework.data.mongodb.repository.support;

