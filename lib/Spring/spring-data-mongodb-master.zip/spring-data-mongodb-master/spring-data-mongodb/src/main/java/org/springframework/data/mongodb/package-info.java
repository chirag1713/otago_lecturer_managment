/**
 * Spring Data's MongoDB abstraction.
 */
package org.springframework.data.mongodb;

