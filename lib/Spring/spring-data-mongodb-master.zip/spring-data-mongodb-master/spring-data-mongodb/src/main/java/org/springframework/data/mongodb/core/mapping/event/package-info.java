/**
 * Mapping event callback infrastructure for the MongoDB document-to-object mapping subsystem.
 */
package org.springframework.data.mongodb.core.mapping.event;

