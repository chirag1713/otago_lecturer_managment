/**
 * Support classes to transform SpEL expressions into MongoDB expressions.
 * @since 1.4
 */
package org.springframework.data.mongodb.core.spel;