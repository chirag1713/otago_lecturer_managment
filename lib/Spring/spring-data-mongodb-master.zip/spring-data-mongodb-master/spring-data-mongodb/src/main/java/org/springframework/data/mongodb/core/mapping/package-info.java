/**
 * Infrastructure for the MongoDB document-to-object mapping subsystem.
 */
package org.springframework.data.mongodb.core.mapping;

