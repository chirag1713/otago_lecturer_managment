/**
 * Support for MongoDB GridFS feature.
 */
package org.springframework.data.mongodb.gridfs;

