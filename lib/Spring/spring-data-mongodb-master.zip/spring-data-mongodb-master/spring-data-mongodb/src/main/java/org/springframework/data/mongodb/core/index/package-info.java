/**
 * Support for MongoDB document indexing.
 */
package org.springframework.data.mongodb.core.index;

