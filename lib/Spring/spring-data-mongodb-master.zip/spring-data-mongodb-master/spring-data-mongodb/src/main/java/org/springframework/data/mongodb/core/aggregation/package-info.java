/**
 * Support for the MongoDB aggregation framework.
 * @since 1.3
 */
package org.springframework.data.mongodb.core.aggregation;