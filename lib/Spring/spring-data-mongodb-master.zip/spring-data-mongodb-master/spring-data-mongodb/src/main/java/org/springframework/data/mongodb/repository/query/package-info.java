/**
 * Query derivation mechanism for MongoDB specific repositories.
 */
package org.springframework.data.mongodb.repository.query;

