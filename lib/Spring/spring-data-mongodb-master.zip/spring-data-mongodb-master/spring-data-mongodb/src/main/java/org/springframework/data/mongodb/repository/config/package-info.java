/**
 * Support infrastructure for the configuration of MongoDB specific repositories.
 */
package org.springframework.data.mongodb.repository.config;

