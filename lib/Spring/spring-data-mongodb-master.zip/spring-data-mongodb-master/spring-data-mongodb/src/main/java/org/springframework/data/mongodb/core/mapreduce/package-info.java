/**
 * Support for MongoDB map-reduce operations.
 */
package org.springframework.data.mongodb.core.mapreduce;

