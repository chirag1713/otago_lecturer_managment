/**
 * MongoDB specific query and update support.
 */
package org.springframework.data.mongodb.core.query;

