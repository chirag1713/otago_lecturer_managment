/**
 * MongoDB core support.
 */
package org.springframework.data.mongodb.core;

