/**
 * Spring XML namespace configuration for MongoDB specific repositories.
 */
package org.springframework.data.mongodb.config;

