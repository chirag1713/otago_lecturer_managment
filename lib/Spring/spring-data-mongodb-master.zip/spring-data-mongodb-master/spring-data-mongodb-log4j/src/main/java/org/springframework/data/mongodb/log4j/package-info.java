/**
 * Infrastructure for to use MongoDB as a logging sink.
 */
package org.springframework.data.mongodb.log4j;

